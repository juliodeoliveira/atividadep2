import java.io.*;
import java.util.ArrayList;

public class Arquivo {

    private String FilePath;
    public Arquivo(String FilePath){
        this.FilePath = FilePath;
    }
    public void criarArquivo(){
        File arq = new File(this.FilePath);//instancia e define o nome do arquivo
        try{
            if(arq.createNewFile()){
                System.out.println("Arquivo criado: "+arq.getName());
            }else{
                System.out.println("Arquivo ja existe");
            }
        }catch (IOException e){
            System.out.println("Deu erro manim!");
        }
    }
    public void limpaArquivo(){
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(this.FilePath))){
            escritor.write("");


        }catch (IOException e){
            System.out.println("deu erro na escrita!");
        }
    }

    public void escreverArquivo(String text){
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(this.FilePath, true))){
            escritor.write(text);


        }catch (IOException e){
            System.out.println("deu erro na escrita!");
        }
    }

    public ArrayList<String> readFileArray() {
        ArrayList<String> teste = new ArrayList<>();
        try(BufferedReader leitor = new BufferedReader(new FileReader(this.FilePath))){
            String text = "";
            String result = "";

            while(true){
                text = leitor.readLine();
                if(text == null){
                    break;
                }

                teste.add((text+"\n"));


            }

            leitor.close();
            return teste;

        }
        catch (IOException e){
            System.out.println("Deu erro na leitura "+e);
        }

        return teste;
    }


    public String readFile() {
        try(BufferedReader leitor = new BufferedReader(new FileReader(this.FilePath))){
            String text = "";
            String result = "";

            while(true){
                text = leitor.readLine();
                if(text == null){
                    break;
                }
                result += (text+"\n");


            }

            leitor.close();
            return result;

        }
        catch (IOException e){
            System.out.println("Deu erro na leitura "+e);
        }

        return "null";
    }
}
