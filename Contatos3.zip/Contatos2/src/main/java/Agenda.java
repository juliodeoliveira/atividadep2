import java.util.ArrayList;
import java.util.stream.Collectors;

public class Agenda {
    private int Id;
    private String nome;
    private Arquivo arquivo;
    private ArrayList<Contato> contatos = new ArrayList<>();

    public Agenda() {
        this.arquivo = new Arquivo("teste.txt");
        this.arquivo.criarArquivo();

        //contatos = this.arquivo.readFileArray();


    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void adicionarContato(Contato contact) {
        this.arquivo.escreverArquivo(contact.getNome() + " | " + contact.getTelefone() + " | " + contact.getEmail()+ "\n");
    }

//    public int verificarUltimoId(){
//        ArrayList<String> conteudo = this.arquivo.readFileArray();
//
//        if(conteudo.isEmpty()){
//           return 0;
//        }
//        String UltimaLinha = conteudo.getLast();
//        return Integer.parseInt(UltimaLinha.split(" | ")[0])+1;
//       // String[] arrayContent = conteudo.split("\\|");
//
//
//    }

    public ArrayList<Contato> lerContato(String valor){

        ArrayList<String> retorno = new ArrayList<>();
        ArrayList<String> conteudo = this.arquivo.readFileArray();
        ArrayList<Contato> contatos = new ArrayList<>();

        for (String conte: conteudo) {
            String[] part = conte.split("\\|");

            int id = Integer.parseInt(part[0].trim());
            String name = part[1].trim();
            String number = part[2].trim();
            String email = part[3].trim();

            Contato contact = new Contato();
            contact.setNome(name);
            contact.setTelefone(number);
            contact.setEmail(email);

            if (contact.getNome().contains(valor) || contact.getEmail().contains(valor) || contact.getTelefone().contains(valor)) {
                contatos.add(contact);
            }
        }

        return contatos;
    }

    public void apagarContato(int Id){
//        String TotalContact = "";
//        ArrayList<String> conteudo = this.arquivo.readFileArray();
//        ArrayList<String> conteudoStream = conteudo.stream().filter(c -> !c.toLowerCase().startsWith(Integer.toString(Id))).collect(Collectors.toList());
//        this.arquivo.limpaArquivo();
//
//        for (String contact: conteudoStream){
//            TotalContact += contact;
//            //this.arquivo.escreverArquivo(contact);
//        }
//        this.arquivo.escreverArquivo(TotalContact);


    }

    public ArrayList<Contato> allContacts() {
        ArrayList<String> content = this.arquivo.readFileArray();
        ArrayList<Contato> contacts = new ArrayList<>();

        for (String contact: content) {
            String[] part = contact.split("\\|");

            int id = Integer.parseInt(part[0].trim());
            String name = part[1].trim();
            String number = part[2].trim();
            String email = part[3].trim();

            Contato contactObject = new Contato();
            contactObject.setId(id);
            contactObject.setNome(name);
            contactObject.setTelefone(number);
            contactObject.setEmail(email);


            contacts.add(contactObject);
        }

        return contacts;
    }
}
