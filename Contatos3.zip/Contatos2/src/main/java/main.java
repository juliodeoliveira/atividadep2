import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        Agenda agenda = new Agenda();
        Contato contato = new Contato();


        int op=0;
        String nomeContato;
        String telContato;
        String email;
        ArrayList<Contato> result;


        do {
            System.out.print("1-Criar contatos\n2-Ler todos contatos\n3-Buscar contato\n4-Apagar contato\n5-Sair\nEscolha uma opção: ");

            op = ler.nextInt();
            ler.nextLine();
            switch (op) {
                case 1:
                    System.out.print("Digite o nome do contato: ");
                    nomeContato = ler.nextLine();
                    contato.setNome(nomeContato);

                    System.out.print("Digite o telefone do contato: ");
                    telContato = ler.nextLine();
                    contato.setTelefone(telContato);

                    System.out.print("Digite o email do contato: ");
                    email = ler.nextLine();
                    contato.setEmail(email);

                    agenda.adicionarContato(contato);

                    break;
                case 2:
                    System.out.println("Segue a lista de contatos:");
                    System.out.println("----------------------------------------------------");
//                    contact.lerTodosContatos();
                    System.out.println("----------------------------------------------------");
                    break;
                case 3:
                    System.out.print("Digite o nome, numero ou email do contato: ");
                    nomeContato = ler.nextLine();
                    System.out.println("\nContatos encontrados: ");
                    System.out.println("----------------------------------------------------");
                    result = agenda.lerContato(nomeContato);
                    if(result.isEmpty()){
                        System.out.println("Nenhum contato encontrado!");
                    }
                    else{
                        for(Contato c: result){
                            if (result.isEmpty()) {
                                System.out.println("Nenhum contato encontrado!");
                            } else {
                                System.out.print(c.getId() + " ~ ");
                                System.out.print(c.getNome() + " ~ ");
                                System.out.print(c.getEmail() + " ~ ");
                                System.out.print(c.getTelefone() + "\n");
                            }
                        }
                    }

                    System.out.println("----------------------------------------------------");
                    break;
                case 4:
                    System.out.print("Digite o nome ou numero do contato: ");
                    nomeContato = ler.nextLine();

                    result = agenda.lerContato(nomeContato);
                    if(result == null){
                        System.out.println("----------------------------------------------------");
                        System.out.println("Nenhum contato encontrado!");
                        System.out.println("----------------------------------------------------");

                    }
                    else {
                        System.out.println("\nContatos encontrados: ");
                        System.out.println("----------------------------------------------------");
                        for (Contato c : result) {
                            System.out.println(c);
                        }
                        System.out.println("----------------------------------------------------");
                        System.out.print("Digite o ID do contato que quer apagar: ");
                        agenda.apagarContato(ler.nextInt());
                    }

                    break;
            }
        }while (op!=5);



//
//        while(true) {
//            l = ler.nextLine();
//            if (l.equals("fim")) {
//                break;
//            }
//
//            if (l.equals("bananao")) {
//                continue;
//            }
//
//            total += (l + "\n");
//            arq.escreverArquivo(total);
//        }
    }
}
